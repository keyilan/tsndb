

# subtribe

````
{
    _id: 5c700aadef919201e4a555eb,
    general: 'mossang',
    autonym: {
        orthography: 'muixshaungx',
        phonemic: 'mɯ₂ʃauŋ₂'
    },
    classifications: [ 'Rangpang', 'Pangwa', 'Tangsa' ],
    villages: [ 'raungghuil2019', 'neotan2019', 'hedman2019' ],
    consultants: [ 'wanglungmos', 'renmanmos', 'cantumos' ] }

````

# consultant

````
{
    "_id":"5c71aa9a699da83c6f30f97f",
    "id":"wanglungmos",
    "name":{
        "given":{"orthography":"Waunglung","phonemic":"βauŋluŋ"},
        "surname":{"orthography":"Keluim","phonemic":"kʰelɯm"},
        "clan":"khanglim"
    },
    "dob":"1960",
    "birthplace":"Raungghuil",
    "notes":"",
    "language":{"native":"Muishaung","mothers":"Muishaung","fathers":"Muishaung"}
}
````
