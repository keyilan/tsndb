document.getElementById("nav-home").classList.remove('uk-active');

if (active == 'subtribes') {
    document.getElementById("nav-subtribes").classList.add('uk-active');
}

if (active == 'home') {
    document.getElementById("nav-home").className = "uk-active";
}


